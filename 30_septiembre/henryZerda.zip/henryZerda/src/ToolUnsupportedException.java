public class ToolUnsupportedException extends Exception {
    public ToolUnsupportedException(String message) {
        super(message);
    }
}
