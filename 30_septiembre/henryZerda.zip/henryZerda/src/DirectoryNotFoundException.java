public class DirectoryNotFoundException extends Exception {
    public DirectoryNotFoundException(String message) {
        super(message);
    }
}
