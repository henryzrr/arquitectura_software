public class CommandUnsupportedException extends Exception{
    public CommandUnsupportedException(String message ) {
        super(message);
    }
}
