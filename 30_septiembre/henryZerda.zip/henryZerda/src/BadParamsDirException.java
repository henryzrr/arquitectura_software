public class BadParamsDirException extends Exception {
    public BadParamsDirException(String message ) {
        super(message);
    }
}
