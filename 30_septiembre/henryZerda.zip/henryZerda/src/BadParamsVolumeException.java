public class BadParamsVolumeException extends Exception{
    public BadParamsVolumeException(String message) {
        super(message);
    }
}
