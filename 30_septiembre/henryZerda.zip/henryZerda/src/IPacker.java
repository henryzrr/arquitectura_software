public interface IPacker {
    void startPacking()throws Exception;
}
