public interface ICommand {
    void execute() throws Exception;
}
