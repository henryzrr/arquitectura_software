import java.util.Map;

public interface ITool {

    void applyTool(String dirCallFunction) throws Exception;
}
