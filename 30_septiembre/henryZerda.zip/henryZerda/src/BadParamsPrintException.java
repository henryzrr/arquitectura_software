public class BadParamsPrintException extends Exception {
    public BadParamsPrintException(String message  ) {
        super(message);
    }
}
