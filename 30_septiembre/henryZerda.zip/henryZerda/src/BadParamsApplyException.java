public class BadParamsApplyException extends Exception {
    public BadParamsApplyException(String message) {
        super(message);
    }
}
