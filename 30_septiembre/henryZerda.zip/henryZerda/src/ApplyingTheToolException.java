public class ApplyingTheToolException extends Exception {
    public ApplyingTheToolException(String message, Throwable cause) {
        super(message, cause);
    }
}
