

public interface ICompiler {
    void compileAll(Directory directory) throws Exception;
}
