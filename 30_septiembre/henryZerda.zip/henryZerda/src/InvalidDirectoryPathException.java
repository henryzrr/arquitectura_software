public class InvalidDirectoryPathException extends Exception {
    public InvalidDirectoryPathException(String message) {
        super(message);
    }
}
