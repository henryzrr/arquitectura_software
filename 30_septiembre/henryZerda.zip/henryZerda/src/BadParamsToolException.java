public class BadParamsToolException extends Exception {
    public BadParamsToolException(String message) {
        super(message);
    }
}
