public class BobFileNotFoundException extends Exception {
    public BobFileNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
