public class BobConfUnsupportedInstructionException extends Exception {
    public BobConfUnsupportedInstructionException(String message, Throwable cause) {
        super(message, cause);
    }
}
