public class Main {
    public static void main(String []args){
        String path = System.getProperty("user.dir");
        System.out.println("Este programa esta corriendo en: "+path);
    }
}
